<?php

/**
 * Provide a client-side-facing view for the plugin
 *
 * This file is used to markup the client-side-facing aspects of the plugin.
 *
 * @link       http://dllstudios.com
 * @since      1.0.0
 *
 * @package    Dlls_Cp
 * @subpackage Dlls_Cp/client-side/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
